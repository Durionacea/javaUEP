package GraKosci;

public class Gracz {

	private String imie;
	private int punkty;
	private int wygrane;
	
	
	public Gracz(String imie) {
		this.imie = imie;
	}
	
	
	
	//gettery
	public String getImie() {
		return this.imie;
	}
	
	public int getPunkty() {
		return this.punkty;
	}
	
	public int getWygrane() {
		return this.wygrane;
	}
	
	public void dodajPunkty(int punkty) {
		this.punkty += punkty;
	}
	
	public void wyzerujPunkty() {
		this.punkty = 0;
	}
	
	public void dodajWygrana() {
		this.wygrane += 1;
	}
	
}
