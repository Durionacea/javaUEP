package GraKosci;

public class Main {

	public static void main(String[] args) {
		
		Gra rozgrywka = new Gra();
		rozgrywka.rozgrywka();
		
		

	}
	
}
