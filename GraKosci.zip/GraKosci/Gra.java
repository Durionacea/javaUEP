package GraKosci;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Gra {
	
	static int liczbaRund;
	static int liczbaKostek;
	static int liczbaScianKostki;
	static List<Gracz> listaGraczy = new ArrayList<>();
	
	Scanner input = null;
	
	public Gra() {
		this.input = new Scanner(System.in);
		
		System.out.println("Witaj w grze w kosci!");
		dodajGraczy();
		
		System.out.println("Wybierz liczbę kostek:");
		liczbaKostek = input.nextInt();
		
		System.out.println("Wybierz ilość ścian kostek:");
		liczbaScianKostki = input.nextInt();
		
		System.out.println("Wpisz liczbę rund:");
		liczbaRund = input.nextInt();
	}
	
	
	
	public void rozgrywka() {
		
		System.out.println("Rozpoczynam rozgrywkę...");
		
		Random random = new Random();
		
		for (int i=1; i<=liczbaRund; i++) {
			System.out.println("Runda: " + i);
			System.out.println();
			
			for (int j=0; j<listaGraczy.size(); j++) {
				listaGraczy.get(j).wyzerujPunkty();
				System.out.println("Tura gracza " + listaGraczy.get(j).getImie());
				System.out.println("Rzucam " +liczbaKostek+ " koscmi");
			
				
				int wynik = random.nextInt(liczbaScianKostki*liczbaKostek)+liczbaKostek;
				System.out.println("Liczba wyrzuconych oczek: " + wynik);
				System.out.println();
				listaGraczy.get(j).dodajPunkty(wynik);				
			}
			porownajPunkty();
			kolejnaRunda();
		}	
		
		porownajWygrane();
		
		input.close();
	}
	
	
	
	public void dodajGraczy() {
			
		int on = 1;
			while (on ==1) {
				System.out.println("Wybierz opcje:");
				System.out.println("1. Dodaj gracza");
				System.out.println("2. Przejdz dalej");
				
				
				
				int wybor = input.nextInt();
				input.nextLine();
				
				switch(wybor) {
					case 1:
						String imieGracza;
						System.out.println("Podaj imie gracza:");
						imieGracza = input.nextLine();
						
						Gracz gracz = new Gracz(imieGracza);
						listaGraczy.add(gracz);	
						break;
					case 2:
						on = 0;
						break;
				}
			}
		}

	
	public void porownajPunkty() {
		
		int najwyzszyWynik = 0;
		Gracz zwyciezca = null;
		for (int k=0; k<listaGraczy.size();k++) {
			Gracz aktualniePorownywany = listaGraczy.get(k);
			if (aktualniePorownywany.getPunkty()>najwyzszyWynik) {
				najwyzszyWynik = aktualniePorownywany.getPunkty();
				zwyciezca = aktualniePorownywany;
			}
		}
		
		System.out.println("Rundę wygrywa " + zwyciezca.getImie() + " z wynikiem: " + najwyzszyWynik + " punktów");
		System.out.println();
		zwyciezca.dodajWygrana();
	}
	
	public void porownajWygrane() {
		int najwiecejWygranych = 0;
		Gracz zwyciezcaGry = null;
		for (int k=0; k<listaGraczy.size();k++) {
			Gracz aktualniePorownywany = listaGraczy.get(k);
			if (aktualniePorownywany.getWygrane()>najwiecejWygranych) {
				najwiecejWygranych = aktualniePorownywany.getWygrane();
				zwyciezcaGry = aktualniePorownywany;
			}
		}
		
		System.out.println("Grę wygrywa " + zwyciezcaGry.getImie() + " z " + zwyciezcaGry.getWygrane() + " wygranymi!");
	}
	
	public void kolejnaRunda() {
		
		boolean nie = true;
		
		while (nie) {
		
			System.out.println("Czy przejść do następnej rundy?");
			int wybor;
			System.out.println("1. Tak");
			System.out.println("2. Zakończ");
			
			wybor = input.nextInt();
			
			switch(wybor) {
			
			case 1:
				nie = false;
				break;
			case 2:
				input.close();
				System.exit(0);
				break;
			}
		}
	}
}
